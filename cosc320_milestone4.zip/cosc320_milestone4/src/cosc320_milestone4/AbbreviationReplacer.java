package cosc320_milestone4;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class AbbreviationReplacer {
	public static void main(String[] args) {
		long stime = System.currentTimeMillis();
		String txtPath = "src/m4txt.txt";
		String txt = filereader(txtPath);
		run(txt);

		long etime = System.currentTimeMillis();
		System.out.printf("run time:%d ms.", (etime - stime));
	}
	public static void run(String str) {
		// Run function
		ArrayList<String> wordList = divideText(str);
		Map<String, String> abbreviationDictionary = new HashMap<>();
		String file = "src/slang.csv";
		abbreviationDictionary=readcsv(file);
		replace(abbreviationDictionary, wordList);
		System.out.println("Before change: " + str);
		System.out.println("After change: " + mergeText(wordList) + "\n");
	}
	public static ArrayList<String> divideText(String text) {
		// Split the article into spaces and save punctuation separately
		ArrayList<String> wordList = new ArrayList<>();
		int it = 0;
		for (int i = 0; i < text.length(); i++) {
			if (i == text.length() - 1) {
				if (text.charAt(i) == ',' || text.charAt(i) == '.' || text.charAt(i) == '!' || text.charAt(i) == '?'
						|| text.charAt(i) == ';'|| text.charAt(i) == '\n') {
					String str = text.substring(it, i);
					wordList.add(str);
					String str2 = text.substring(i);
					wordList.add(str2);
				} else {
					String str = text.substring(it, i + 1);
					wordList.add(str);
				}
			}
			// read a word before space
			else if (text.charAt(i) == ' ') {
				String str = text.substring(it, i);
				if(str.contains("\r\n")) {
					String str1 = str.substring(0, str.indexOf("\r\n"));
					
					String str2 = str.substring(str.indexOf("\r\n")+2,str.length());
					wordList.add(str1);
					wordList.add("\r\n");
					wordList.add(str2);
					
					
				}else if(str.contains("\n")){
					String str1 = str.substring(0, str.indexOf("\n"));
					String str2 = str.substring(str.indexOf("\n")+1,str.length());
					wordList.add(str1);
					wordList.add("\n");
					wordList.add(str2);
					
				}else if(str.contains("\r")){
					String str1 = str.substring(0, str.indexOf("\r"));
					String str2 = str.substring(str.indexOf("\r")+1,str.length());
					wordList.add(str1);
					wordList.add("\r");
					wordList.add(str2);
					
				}else {
					wordList.add(str);
				}
				i++;
				it = i;
			}
			// read a word before punctuation
			else if (text.charAt(i) == ',' || text.charAt(i) == '.' || text.charAt(i) == '!' || text.charAt(i) == '?'
					|| text.charAt(i) == ';') {
				String str = text.substring(it, i);
				if(str.contains("\r\n")) {
					String str1 = str.substring(0, str.indexOf("\r\n"));
					String str2 = str.substring(str.indexOf("\r\n")+2,str.length());
					wordList.add(str1);
					wordList.add("\r\n");
					wordList.add(str2);
					
				}else if(str.contains("\n")){
					String str1 = str.substring(0, str.indexOf("\n"));
					String str2 = str.substring(str.indexOf("\n")+1,str.length());
					wordList.add(str1);
					wordList.add("\n");
					wordList.add(str2);
					
				}else if(str.contains("\r")){
					String str1 = str.substring(0, str.indexOf("\r"));
					String str2 = str.substring(str.indexOf("\r")+1,str.length());
					wordList.add(str1);
					wordList.add("\r");
					wordList.add(str2);
					
				}else {
					wordList.add(str);
				}
				it = i;
			}

		}
		return wordList;
	}
	public static String mergeText(ArrayList<String> wordList) {
		// merge the separate word back
		String str = wordList.get(0);
		for (int i = 1; i < wordList.size(); i++) {
			
				if (wordList.get(i).equals(",") || wordList.get(i).equals(".") || wordList.get(i).equals("?")
						|| wordList.get(i).equals("!") || wordList.get(i).equals(";")||(i>1 && (wordList.get(i-1).equals("\r")||wordList.get(i-1).equals("\n")||wordList.get(i-1).equals("\r\n")))) {
					str = str + wordList.get(i);
				} else {
					str = str + " " + wordList.get(i);
				}
			

		}
		return str;
	}

	public static void replace(Map<String, String> abbreviationDictionary, ArrayList<String> wordList) {
		// replace the abbreviation find out from the Dictionary
		for (int i = 0; i < wordList.size(); i++) {
            String word = wordList.get(i).toLowerCase();
            if (abbreviationDictionary.containsKey(word)) {
            	wordList.set(i, abbreviationDictionary.get(word));
            }
        }
	}


	public static Map<String, String> readcsv(String file) {
		// Load Dictionary csv file in a Map
		Map<String, String> abbreviationDictionary =new HashMap<>();
		String line = "";
		String[] Line;
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			while ((line = br.readLine()) != null) {
				Line = line.split(",");
				
				abbreviationDictionary.put(Line[1],Line[2]);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return abbreviationDictionary;
	}
	
	public static String filereader(String file) {

		Path path = Paths.get(file);
		String data = null;
		try {
			data = Files.readString(path);
		} catch (IOException e) {

			e.printStackTrace();
		}
		return data;
	}
}
